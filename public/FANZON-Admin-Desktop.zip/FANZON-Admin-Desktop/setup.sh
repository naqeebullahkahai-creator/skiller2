#!/bin/bash
echo "========================================="
echo "   FANZON Admin Desktop - Setup"
echo "========================================="
echo ""
echo "Step 1: Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "[ERROR] npm install failed!"
    exit 1
fi
echo ""
echo "Step 2: Starting FANZON Admin Desktop..."
npm start
