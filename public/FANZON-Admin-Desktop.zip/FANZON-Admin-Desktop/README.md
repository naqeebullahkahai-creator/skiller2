# FANZON Admin Desktop Panel v2.0

## Quick Setup (Windows)
1. Install Node.js from https://nodejs.org (LTS version)
2. Double-click `setup.bat`
3. Done! App will open automatically

## Quick Setup (Mac/Linux)
1. Install Node.js
2. Run: `chmod +x setup.sh && ./setup.sh`

## Build .exe Installer
```
npm run build
```
Output: `release/` folder mein .exe milega

## Features
- Real-time admin panel (web app wrapped in Electron)
- Offline mode with cached data
- Auto-reconnect when internet available
- Windows/Mac/Linux support

## API Keys (Pre-configured)
- Supabase URL & Key already included in code
- No manual configuration needed!
