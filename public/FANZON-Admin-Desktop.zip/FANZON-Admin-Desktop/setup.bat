@echo off
echo =========================================
echo    FANZON Admin Desktop - Setup
echo =========================================
echo.
echo Step 1: Installing dependencies...
call npm install
if errorlevel 1 (
    echo [ERROR] npm install failed!
    pause
    exit /b 1
)
echo.
echo Step 2: Starting FANZON Admin Desktop...
call npm start
pause
