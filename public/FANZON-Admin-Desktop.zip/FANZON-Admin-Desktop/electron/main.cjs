const { app, BrowserWindow, ipcMain, Menu, Tray, nativeImage } = require("electron");
const path = require("path");
const Store = require("electron-store");

const store = new Store();

// Supabase Config - ALREADY CONFIGURED
const SUPABASE_URL = "https://faevzfibzcbuqjoatmjm.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhZXZ6ZmliemNidXFqb2F0bWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE3OTM4OTQsImV4cCI6MjA4NzM2OTg5NH0.1P6q4Xo5xKWHExRnUOaQPjwq-AxmQ6K4Sp4FTpWPXGM";

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    title: "FANZON Admin Panel",
    icon: path.join(__dirname, "../assets/icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
    },
    frame: true,
    autoHideMenuBar: true,
  });

  // Load the web admin panel directly
  mainWindow.loadURL("https://fanzoon.lovable.app/admin");

  // Handle offline - show cached version
  mainWindow.webContents.on("did-fail-load", () => {
    mainWindow.loadFile(path.join(__dirname, "../offline/index.html"));
  });

  // Inject Supabase credentials
  mainWindow.webContents.on("did-finish-load", () => {
    mainWindow.webContents.executeJavaScript(`
      window.__FANZON_DESKTOP__ = true;
      window.__FANZON_APP_TYPE__ = "admin";
      console.log("FANZON Admin Desktop v2.0 loaded");
    `);
  });
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });

// IPC Handlers
ipcMain.handle("get-config", () => ({
  supabaseUrl: SUPABASE_URL,
  supabaseKey: SUPABASE_ANON_KEY,
  appType: "admin"
}));

ipcMain.handle("get-store", (_, key) => store.get(key));
ipcMain.handle("set-store", (_, key, value) => store.set(key, value));
ipcMain.handle("is-online", () => require("dns").promises.lookup("google.com").then(() => true).catch(() => false));
