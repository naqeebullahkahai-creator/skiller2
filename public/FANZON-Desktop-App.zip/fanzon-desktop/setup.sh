#!/bin/bash
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║     FANZON Seller Center - Setup         ║"
echo "║     Desktop Application Installer        ║"
echo "╚══════════════════════════════════════════╝"
echo ""

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js nahi mila!"
    echo "Pehle install karo: https://nodejs.org"
    exit 1
fi

echo "[OK] Node.js found: $(node --version)"
echo ""
echo "Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "[ERROR] Installation fail!"
    exit 1
fi

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  [SUCCESS] Setup Complete!               ║"
echo "║                                          ║"
echo "║  App chalane ke liye:  npm start         ║"
echo "║  EXE banane ke liye:   npm run package:mac║"
echo "╚══════════════════════════════════════════╝"
