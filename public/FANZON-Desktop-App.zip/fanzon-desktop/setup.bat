@echo off
title FANZON Seller Center - Setup
color 0A

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║     FANZON Seller Center - Setup         ║
echo  ║     Desktop Application Installer        ║
echo  ╚══════════════════════════════════════════╝
echo.

:: Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [ERROR] Node.js nahi mila!
    echo  Pehle install karo: https://nodejs.org
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node --version') do set NODE_VER=%%i
echo  [OK] Node.js found: %NODE_VER%

:: Install dependencies
echo.
echo  Installing dependencies... (2-3 minute lagenge)
echo.
call npm install

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Installation fail ho gayi!
    echo  Internet connection check karein aur dobara try karein.
    pause
    exit /b 1
)

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║  [SUCCESS] Setup Complete!               ║
echo  ║                                          ║
echo  ║  App chalane ke liye:  npm start         ║
echo  ║  EXE banane ke liye:   npm run package:win║
echo  ╚══════════════════════════════════════════╝
echo.
pause
