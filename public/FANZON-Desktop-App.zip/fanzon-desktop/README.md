# FANZON Seller Center - Desktop App

## 🚀 Quick Start (3 Steps)

### Step 1: Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2: Setup
**Windows:** Double-click `setup.bat`
**Mac/Linux:** Run `./setup.sh` in Terminal

### Step 3: Launch
```bash
npm start
```

## 📦 Build Executable

| Platform | Command |
|----------|---------|
| Windows .exe | `npm run package:win` |
| macOS .app | `npm run package:mac` |
| Linux | `npm run package:linux` |

Output: `release/` folder

## 🔑 API Configuration

| Key | Value |
|-----|-------|
| Supabase URL | `https://faevzfibzcbuqjoatmjm.supabase.co` |
| Anon Key | Already embedded in code |
| Sync API | `https://faevzfibzcbuqjoatmjm.supabase.co/functions/v1/sync-products` |

## 📁 Project Structure

```
fanzon-desktop-app/
├── electron/
│   ├── main.cjs          # Main Electron process
│   └── preload.cjs        # Secure bridge API
├── assets/
│   └── icon.png           # App icon
├── offline.html           # Offline fallback page
├── package.json           # Dependencies & scripts
├── setup.bat              # Windows auto-setup
├── setup.sh               # Mac/Linux auto-setup
└── README.md              # This file
```

## ❓ Troubleshooting

| Problem | Solution |
|---------|----------|
| "npm" not found | Install Node.js from nodejs.org |
| White/blank screen | Check internet connection |
| npm install fails | Run `node --version` (need v18+) |
| Build fails | Run `npm install` first |

© 2026 FANZON Marketplace
