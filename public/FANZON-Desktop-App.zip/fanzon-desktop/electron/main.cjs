const { app, BrowserWindow, Menu, Tray, shell, ipcMain, Notification } = require("electron");
const path = require("path");

// ─── CONFIG ───
const APP_NAME = "FANZON Seller Center";
const APP_URL = "https://fanzoon.lovable.app/seller-center/dashboard";
const SUPABASE_URL = "https://faevzfibzcbuqjoatmjm.supabase.co";
const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhZXZ6ZmliemNidXFqb2F0bWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE3OTM4OTQsImV4cCI6MjA4NzM2OTg5NH0.1P6q4Xo5xKWHExRnUOaQPjwq-AxmQ6K4Sp4FTpWPXGM";
const SYNC_API = `${SUPABASE_URL}/functions/v1/sync-products`;

let mainWindow = null;
let tray = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    title: APP_NAME,
    icon: path.join(__dirname, "..", "assets", "icon.png"),
    backgroundColor: "#0F766E",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true,
    },
  });

  // ─── Custom Menu ───
  const menuTemplate = [
    {
      label: "FANZON",
      submenu: [
        { label: "Dashboard", click: () => mainWindow.loadURL(APP_URL) },
        { label: "Add Product", click: () => mainWindow.loadURL("https://fanzoon.lovable.app/seller-center/add-product") },
        { label: "My Products", click: () => mainWindow.loadURL("https://fanzoon.lovable.app/seller-center/products") },
        { label: "Orders", click: () => mainWindow.loadURL("https://fanzoon.lovable.app/seller-center/orders") },
        { type: "separator" },
        { label: "Wallet", click: () => mainWindow.loadURL("https://fanzoon.lovable.app/seller-center/wallet") },
        { label: "Analytics", click: () => mainWindow.loadURL("https://fanzoon.lovable.app/seller-center/analytics") },
        { type: "separator" },
        { label: "Quit", accelerator: "CmdOrCtrl+Q", click: () => app.quit() },
      ],
    },
    {
      label: "Edit",
      submenu: [
        { role: "undo" }, { role: "redo" }, { type: "separator" },
        { role: "cut" }, { role: "copy" }, { role: "paste" }, { role: "selectAll" },
      ],
    },
    {
      label: "View",
      submenu: [
        { role: "reload" }, { role: "forceReload" },
        { type: "separator" },
        { role: "zoomIn" }, { role: "zoomOut" }, { role: "resetZoom" },
        { type: "separator" },
        { role: "togglefullscreen" },
        { role: "toggleDevTools" },
      ],
    },
    {
      label: "Help",
      submenu: [
        { label: "FANZON Website", click: () => shell.openExternal("https://fanzoon.lovable.app") },
        { label: "Seller Guide", click: () => shell.openExternal("https://fanzoon.lovable.app/how-to-buy") },
        { type: "separator" },
        { label: `About ${APP_NAME}`, click: () => {
          const { dialog } = require("electron");
          dialog.showMessageBox(mainWindow, {
            type: "info",
            title: `About ${APP_NAME}`,
            message: APP_NAME,
            detail: "Version 1.0.0\n\nManage your FANZON store from your desktop.\nAdd products, manage orders, track earnings.\n\n© 2026 FANZON Marketplace",
          });
        }},
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(menuTemplate));

  // ─── Load App ───
  mainWindow.loadURL(APP_URL);

  // Show window when ready
  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
    // Show welcome notification
    if (Notification.isSupported()) {
      new Notification({
        title: "FANZON Seller Center",
        body: "Welcome! Your seller dashboard is ready.",
        icon: path.join(__dirname, "..", "assets", "icon.png"),
      }).show();
    }
  });

  // Handle offline - show custom offline page
  mainWindow.webContents.on("did-fail-load", (event, errorCode, errorDescription) => {
    if (errorCode === -106 || errorCode === -105 || errorCode === -109) {
      mainWindow.loadFile(path.join(__dirname, "..", "offline.html"));
    }
  });

  // Open external links in browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith("https://fanzoon.lovable.app")) {
      shell.openExternal(url);
      return { action: "deny" };
    }
    return { action: "allow" };
  });

  mainWindow.on("closed", () => { mainWindow = null; });
}

// ─── Single Instance Lock ───
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
