const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("fanzonAPI", {
  // App Info
  getAppVersion: () => "1.0.0",
  getAppName: () => "FANZON Seller Center",
  getPlatform: () => process.platform,

  // API Config
  getConfig: () => ({
    supabaseUrl: "https://faevzfibzcbuqjoatmjm.supabase.co",
    anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhZXZ6ZmliemNidXFqb2F0bWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE3OTM4OTQsImV4cCI6MjA4NzM2OTg5NH0.1P6q4Xo5xKWHExRnUOaQPjwq-AxmQ6K4Sp4FTpWPXGM",
    syncApi: "https://faevzfibzcbuqjoatmjm.supabase.co/functions/v1/sync-products",
  }),

  // Notifications
  sendNotification: (title, body) => ipcRenderer.send("show-notification", { title, body }),

  // Window controls
  minimize: () => ipcRenderer.send("window-minimize"),
  maximize: () => ipcRenderer.send("window-maximize"),
  close: () => ipcRenderer.send("window-close"),
});
