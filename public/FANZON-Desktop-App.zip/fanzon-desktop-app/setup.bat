@echo off
echo ========================================
echo    FANZON Desktop App Setup (Windows)
echo ========================================
echo.
echo Installing dependencies...
call npm install
echo.
echo Starting app...
call npm start
