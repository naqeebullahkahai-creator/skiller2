#!/bin/bash
echo "FANZON Desktop App Setup"
npm install
npm start
