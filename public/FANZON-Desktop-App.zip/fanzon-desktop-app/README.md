# FANZON Seller Center - Desktop App

## Quick Start
1. Install Node.js 18+ from https://nodejs.org
2. Run: npm install
3. Run: npm start

## Build .exe
Run: npm run package:win
Output: release/FANZON-Seller-win32-x64/
