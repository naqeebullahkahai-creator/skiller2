const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("fanzonAdmin", {
  getConfig: () => ipcRenderer.invoke("get-config"),
  getTheme: () => ipcRenderer.invoke("get-theme"),
  setTheme: (mode) => ipcRenderer.invoke("set-theme", mode),
  platform: process.platform,
  version: process.env.npm_package_version || "1.0.0",
});
