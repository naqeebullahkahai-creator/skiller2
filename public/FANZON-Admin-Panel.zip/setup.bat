@echo off
echo ============================================
echo   FANZON Admin Panel - Setup (Windows)
echo ============================================
echo.
echo Checking Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js not found! Download from: https://nodejs.org
    pause
    exit /b 1
)
echo [OK] Node.js found
echo.
echo Installing dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] npm install failed!
    pause
    exit /b 1
)
echo.
echo [OK] Setup complete!
echo.
echo To start: npm start
echo To build .exe: npm run package:win
echo.
pause
