# FANZON Admin Panel - Desktop Application

## Quick Start
1. Install Node.js v18+ from https://nodejs.org
2. Run `setup.bat` (Windows) or `setup.sh` (Mac/Linux)
3. Run `npm start` to open the admin panel

## Build .exe
```
npm run package:win
```
Output will be in `release/` folder.

## Features
- Admin Login (Supabase Auth)
- Dashboard with live stats
- Sellers Management (Approve/Block)
- Products Management (Approve/Reject)
- Orders Management (Status updates)
- Withdrawal Requests (Approve/Reject)
- Offline mode with IndexedDB
- Auto-sync when internet available
- Dark/Light theme
