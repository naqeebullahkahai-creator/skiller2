/**
 * FANZON Admin - Supabase API Layer
 * Handles all online communication with Supabase
 */

class SupabaseAPI {
  constructor(url, anonKey) {
    this.url = url;
    this.anonKey = anonKey;
    this.accessToken = null;
    this.refreshToken = null;
    this.user = null;
  }

  get headers() {
    const h = {
      "Content-Type": "application/json",
      "apikey": this.anonKey,
      "Authorization": this.accessToken ? `Bearer ${this.accessToken}` : `Bearer ${this.anonKey}`,
    };
    return h;
  }

  async request(endpoint, options = {}) {
    const res = await fetch(`${this.url}${endpoint}`, {
      ...options,
      headers: { ...this.headers, ...(options.headers || {}) },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(err.message || err.error_description || "API Error");
    }
    return res.json();
  }

  // Auth
  async login(email, password) {
    const data = await this.request("/auth/v1/token?grant_type=password", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    this.accessToken = data.access_token;
    this.refreshToken = data.refresh_token;
    this.user = data.user;
    
    // Verify admin role
    const roleData = await this.request(
      `/rest/v1/user_roles?user_id=eq.${data.user.id}&select=role`,
      { method: "GET" }
    );
    
    if (!roleData.length || roleData[0].role !== "admin") {
      this.accessToken = null;
      this.refreshToken = null;
      this.user = null;
      throw new Error("Access denied. Admin role required.");
    }
    
    return { user: data.user, role: "admin" };
  }

  async refreshSession() {
    if (!this.refreshToken) return false;
    try {
      const data = await this.request("/auth/v1/token?grant_type=refresh_token", {
        method: "POST",
        body: JSON.stringify({ refresh_token: this.refreshToken }),
      });
      this.accessToken = data.access_token;
      this.refreshToken = data.refresh_token;
      return true;
    } catch { return false; }
  }

  async changePassword(newPassword) {
    return this.request("/auth/v1/user", {
      method: "PUT",
      body: JSON.stringify({ password: newPassword }),
    });
  }

  // Data fetching
  async getSellers() {
    return this.request("/rest/v1/seller_profiles?select=*,profiles(full_name,email,phone)&order=created_at.desc");
  }

  async getProducts() {
    return this.request("/rest/v1/products?select=*&order=created_at.desc&limit=500");
  }

  async getOrders() {
    return this.request("/rest/v1/orders?select=*&order=created_at.desc&limit=500");
  }

  async getPayouts() {
    return this.request("/rest/v1/payout_requests?select=*,seller_wallets(seller_id)&order=created_at.desc");
  }

  async getProfiles() {
    return this.request("/rest/v1/profiles?select=id,full_name,email&limit=1000");
  }

  // Updates
  async updateSeller(id, data) {
    return this.request(`/rest/v1/seller_profiles?user_id=eq.${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
      headers: { "Prefer": "return=representation" },
    });
  }

  async updateProduct(id, data) {
    return this.request(`/rest/v1/products?id=eq.${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
      headers: { "Prefer": "return=representation" },
    });
  }

  async updateOrder(id, data) {
    return this.request(`/rest/v1/orders?id=eq.${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
      headers: { "Prefer": "return=representation" },
    });
  }

  async updatePayout(id, data) {
    return this.request(`/rest/v1/payout_requests?id=eq.${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
      headers: { "Prefer": "return=representation" },
    });
  }

  // Dashboard stats
  async getDashboardStats() {
    const [sellers, products, orders] = await Promise.all([
      this.request("/rest/v1/seller_profiles?select=user_id,verification_status"),
      this.request("/rest/v1/products?select=id,status"),
      this.request("/rest/v1/orders?select=id,order_status,total_amount_pkr"),
    ]);
    
    const revenue = orders
      .filter(o => o.order_status === "delivered")
      .reduce((s, o) => s + (o.total_amount_pkr || 0), 0);

    return {
      totalSellers: sellers.length,
      totalProducts: products.length,
      totalOrders: orders.length,
      totalRevenue: revenue,
      pendingSellers: sellers.filter(s => s.verification_status === "pending").length,
      pendingProducts: products.filter(p => p.status === "pending").length,
    };
  }
}

window.SupabaseAPI = SupabaseAPI;
