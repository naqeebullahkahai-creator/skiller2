/**
 * FANZON Admin - Sync Engine
 * Auto-syncs local IndexedDB with Supabase when online
 */

class SyncEngine {
  constructor(db, api) {
    this.db = db;
    this.api = api;
    this.isSyncing = false;
    this.lastSync = null;
    this.listeners = [];
    this.autoSyncInterval = null;
  }

  onStatusChange(fn) { this.listeners.push(fn); }
  
  emit(status, detail = "") {
    this.listeners.forEach(fn => fn({ status, detail, lastSync: this.lastSync, isSyncing: this.isSyncing }));
  }

  get isOnline() { return navigator.onLine; }

  startAutoSync(intervalMs = 60000) {
    this.stopAutoSync();
    this.autoSyncInterval = setInterval(() => {
      if (this.isOnline && !this.isSyncing) this.fullSync();
    }, intervalMs);
    
    window.addEventListener("online", () => {
      this.emit("online", "Internet connected — syncing...");
      setTimeout(() => this.fullSync(), 2000);
    });
    window.addEventListener("offline", () => this.emit("offline", "Working offline"));
  }

  stopAutoSync() {
    if (this.autoSyncInterval) clearInterval(this.autoSyncInterval);
  }

  async fullSync() {
    if (this.isSyncing || !this.isOnline) return;
    this.isSyncing = true;
    this.emit("syncing", "Downloading data from server...");

    try {
      // 1. Pull from server
      const [sellers, products, orders, payouts] = await Promise.all([
        this.api.getSellers(),
        this.api.getProducts(),
        this.api.getOrders(),
        this.api.getPayouts(),
      ]);

      await this.db.putBulk("sellers", sellers || []);
      await this.db.putBulk("products", products || []);
      await this.db.putBulk("orders", orders || []);
      await this.db.putBulk("payouts", payouts || []);

      // 2. Push unsynced local changes
      await this.pushUnsynced("sellers", (id, data) => this.api.updateSeller(id, data));
      await this.pushUnsynced("products", (id, data) => this.api.updateProduct(id, data));
      await this.pushUnsynced("orders", (id, data) => this.api.updateOrder(id, data));
      await this.pushUnsynced("payouts", (id, data) => this.api.updatePayout(id, data));

      this.lastSync = new Date().toISOString();
      await this.db.addSyncLog({ type: "full", status: "success", records: (sellers?.length||0)+(products?.length||0)+(orders?.length||0) });
      this.emit("synced", `Synced at ${new Date().toLocaleTimeString()}`);
    } catch (err) {
      await this.db.addSyncLog({ type: "full", status: "error", error: err.message });
      this.emit("error", err.message);
    } finally {
      this.isSyncing = false;
    }
  }

  async pushUnsynced(storeName, updateFn) {
    const unsynced = await this.db.getUnsynced(storeName);
    for (const item of unsynced) {
      try {
        const { synced, updated_at, ...data } = item;
        await updateFn(item.id || item.user_id, data);
        await this.db.markSynced(storeName, item.id);
      } catch (err) {
        console.warn(`Sync push failed for ${storeName}/${item.id}:`, err.message);
      }
    }
  }
}

window.SyncEngine = SyncEngine;
