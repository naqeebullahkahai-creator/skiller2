/**
 * FANZON Admin - Main Application Logic
 */

let db, api, sync;
let currentPage = "dashboard";
let cachedData = { sellers: [], products: [], orders: [], payouts: [] };

// ========== INIT ==========
async function initApp() {
  const config = window.fanzonAdmin
    ? await window.fanzonAdmin.getConfig()
    : { supabaseUrl: "https://faevzfibzcbuqjoatmjm.supabase.co", anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhZXZ6ZmliemNidXFqb2F0bWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE3OTM4OTQsImV4cCI6MjA4NzM2OTg5NH0.1P6q4Xo5xKWHExRnUOaQPjwq-AxmQ6K4Sp4FTpWPXGM" };

  db = new FanzonDB();
  await db.init();

  api = new SupabaseAPI(config.supabaseUrl, config.anonKey);

  // Check saved session
  const savedToken = await db.getSetting("access_token");
  const savedRefresh = await db.getSetting("refresh_token");
  if (savedToken && savedRefresh) {
    api.accessToken = savedToken;
    api.refreshToken = savedRefresh;
    const refreshed = navigator.onLine ? await api.refreshSession() : true;
    if (refreshed) {
      showApp();
      return;
    }
  }
  showLogin();
}

// ========== AUTH ==========
function showLogin() {
  document.getElementById("loginScreen").classList.remove("hidden");
  document.getElementById("appShell").classList.add("hidden");
  document.getElementById("appShell").style.display = "none";
}

function showApp() {
  document.getElementById("loginScreen").classList.add("hidden");
  document.getElementById("appShell").classList.remove("hidden");
  document.getElementById("appShell").style.display = "flex";

  // Init sync
  sync = new SyncEngine(db, api);
  sync.onStatusChange(updateSyncUI);
  sync.startAutoSync(60000);

  if (navigator.onLine) sync.fullSync().then(() => loadPageData());
  else loadPageData();

  navigate("dashboard");
}

async function handleLogin() {
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;
  const btn = document.getElementById("loginBtn");
  const errEl = document.getElementById("loginError");

  if (!email || !password) { errEl.textContent = "Enter email and password"; errEl.classList.remove("hidden"); return; }

  btn.disabled = true; btn.textContent = "Signing in...";
  errEl.classList.add("hidden");

  try {
    if (!navigator.onLine) {
      const savedEmail = await db.getSetting("admin_email");
      if (savedEmail === email) { showApp(); return; }
      throw new Error("No internet. First login requires internet.");
    }
    await api.login(email, password);
    await db.setSetting("access_token", api.accessToken);
    await db.setSetting("refresh_token", api.refreshToken);
    await db.setSetting("admin_email", email);
    showApp();
  } catch (err) {
    errEl.textContent = err.message; errEl.classList.remove("hidden");
  } finally {
    btn.disabled = false; btn.textContent = "Sign In";
  }
}

async function handleLogout() {
  await db.setSetting("access_token", null);
  await db.setSetting("refresh_token", null);
  api.accessToken = null; api.refreshToken = null;
  sync?.stopAutoSync();
  showLogin();
}

// ========== NAVIGATION ==========
function navigate(page) {
  currentPage = page;
  document.querySelectorAll(".nav-item").forEach(el => {
    el.classList.toggle("active", el.dataset.page === page);
  });
  const titles = { dashboard:"Dashboard", sellers:"Sellers Management", products:"Products Management", orders:"Orders Management", payouts:"Withdrawal Requests", sync:"Sync Status", settings:"Settings" };
  document.getElementById("pageTitle").textContent = titles[page] || page;
  renderPage();
}

async function loadPageData() {
  cachedData.sellers = await db.getAll("sellers");
  cachedData.products = await db.getAll("products");
  cachedData.orders = await db.getAll("orders");
  cachedData.payouts = await db.getAll("payouts");
  updateBadges();
  renderPage();
}

function updateBadges() {
  const ps = cachedData.sellers.filter(s => s.verification_status === "pending").length;
  const pp = cachedData.products.filter(p => p.status === "pending").length;
  const pw = cachedData.payouts.filter(p => p.status === "pending").length;
  document.getElementById("sellersBadge").textContent = ps || "";
  document.getElementById("productsBadge").textContent = pp || "";
  document.getElementById("payoutsBadge").textContent = pw || "";
}

function updateSyncUI(info) {
  const dot = document.getElementById("syncDot");
  const text = document.getElementById("syncText");
  dot.className = "sync-dot " + (info.status === "syncing" ? "syncing" : info.status === "online" || info.status === "synced" ? "online" : "offline");
  text.textContent = info.detail || info.status;
  if (info.status === "synced") loadPageData();
}

// ========== THEME ==========
function toggleTheme() {
  document.body.classList.toggle("light");
  const isLight = document.body.classList.contains("light");
  db?.setSetting("theme", isLight ? "light" : "dark");
  if (window.fanzonAdmin) window.fanzonAdmin.setTheme(isLight ? "light" : "dark");
}

// ========== RENDER PAGES ==========
function renderPage() {
  const el = document.getElementById("pageContent");
  switch (currentPage) {
    case "dashboard": el.innerHTML = renderDashboard(); break;
    case "sellers": el.innerHTML = renderSellers(); break;
    case "products": el.innerHTML = renderProducts(); break;
    case "orders": el.innerHTML = renderOrders(); break;
    case "payouts": el.innerHTML = renderPayouts(); break;
    case "sync": el.innerHTML = renderSync(); break;
    case "settings": el.innerHTML = renderSettings(); break;
  }
}

function formatPKR(n) { return "Rs. " + (n||0).toLocaleString(); }
function statusBadge(s) { return `<span class="status-badge status-${(s||'').toLowerCase()}">${s||'N/A'}</span>`; }
function truncate(s, n=30) { return s && s.length > n ? s.slice(0,n)+"…" : s||"—"; }

// Dashboard
function renderDashboard() {
  const s = cachedData.sellers, p = cachedData.products, o = cachedData.orders;
  const rev = o.filter(x=>x.order_status==="delivered").reduce((a,x)=>a+(x.total_amount_pkr||0),0);
  const pending = o.filter(x=>x.order_status==="pending").length;
  const shipped = o.filter(x=>x.order_status==="shipped").length;
  return `
    <div class="stats-grid">
      <div class="stat-card primary"><div class="label">Total Sellers</div><div class="value">${s.length}</div><div class="sub">${s.filter(x=>x.verification_status==="pending").length} pending approval</div></div>
      <div class="stat-card accent"><div class="label">Total Products</div><div class="value">${p.length}</div><div class="sub">${p.filter(x=>x.status==="pending").length} pending review</div></div>
      <div class="stat-card warning"><div class="label">Total Orders</div><div class="value">${o.length}</div><div class="sub">${pending} pending · ${shipped} shipped</div></div>
      <div class="stat-card success"><div class="label">Total Revenue</div><div class="value">${formatPKR(rev)}</div><div class="sub">From delivered orders</div></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
      <div class="table-card">
        <div class="table-header"><h3>Recent Orders</h3></div>
        <table><thead><tr><th>Order</th><th>Amount</th><th>Status</th></tr></thead><tbody>
        ${o.slice(0,8).map(x=>`<tr><td>${x.order_number||x.id?.slice(0,8)}</td><td>${formatPKR(x.total_amount_pkr)}</td><td>${statusBadge(x.order_status)}</td></tr>`).join("")}
        ${o.length===0?`<tr><td colspan="3" style="text-align:center;color:var(--text3);padding:30px;">No orders yet</td></tr>`:""}
        </tbody></table>
      </div>
      <div class="table-card">
        <div class="table-header"><h3>Pending Sellers</h3></div>
        <table><thead><tr><th>Store</th><th>Status</th><th>Action</th></tr></thead><tbody>
        ${s.filter(x=>x.verification_status==="pending").slice(0,8).map(x=>`<tr><td>${truncate(x.store_name||x.business_name)}</td><td>${statusBadge(x.verification_status)}</td><td><button class="action-btn success" onclick="updateSellerStatus('${x.user_id}','verified')">Approve</button></td></tr>`).join("")}
        ${s.filter(x=>x.verification_status==="pending").length===0?`<tr><td colspan="3" style="text-align:center;color:var(--text3);padding:30px;">No pending sellers</td></tr>`:""}
        </tbody></table>
      </div>
    </div>`;
}

// Sellers
function renderSellers() {
  const s = cachedData.sellers;
  return `
    <div class="table-card">
      <div class="table-header">
        <h3>All Sellers (${s.length})</h3>
        <div class="filter-row">
          <select onchange="filterSellers(this.value)" id="sellerFilter">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="verified">Verified</option>
            <option value="rejected">Rejected</option>
          </select>
          <input placeholder="Search..." oninput="searchSellers(this.value)" />
        </div>
      </div>
      <table><thead><tr><th>Store Name</th><th>Owner</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
      <tbody id="sellersTable">
      ${s.map(x=>`<tr>
        <td><strong>${truncate(x.store_name||x.business_name,25)}</strong></td>
        <td>${x.profiles?.full_name||"—"}</td>
        <td>${statusBadge(x.verification_status)}</td>
        <td style="font-size:11px;color:var(--text3)">${x.created_at?new Date(x.created_at).toLocaleDateString():""}</td>
        <td>
          ${x.verification_status!=="verified"?`<button class="action-btn success" onclick="updateSellerStatus('${x.user_id}','verified')">Approve</button>`:""}
          ${x.verification_status!=="rejected"?`<button class="action-btn danger" onclick="updateSellerStatus('${x.user_id}','rejected')">Block</button>`:""}
        </td></tr>`).join("")}
      ${s.length===0?`<tr><td colspan="5" style="text-align:center;color:var(--text3);padding:40px;">No sellers found</td></tr>`:""}
      </tbody></table>
    </div>`;
}

// Products
function renderProducts() {
  const p = cachedData.products;
  return `
    <div class="table-card">
      <div class="table-header">
        <h3>All Products (${p.length})</h3>
        <div class="filter-row">
          <select onchange="filterProducts(this.value)">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
          <input placeholder="Search..." oninput="searchProducts(this.value)" />
        </div>
      </div>
      <table><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="productsTable">
      ${p.map(x=>`<tr>
        <td><strong>${truncate(x.title,30)}</strong><br><span style="font-size:10px;color:var(--text3)">${x.display_id||""}</span></td>
        <td>${formatPKR(x.discount_price_pkr||x.price_pkr)}</td>
        <td>${x.stock_count||0}</td>
        <td>${statusBadge(x.status)}</td>
        <td>
          ${x.status==="pending"?`<button class="action-btn success" onclick="updateProductStatus('${x.id}','approved')">Approve</button><button class="action-btn danger" onclick="updateProductStatus('${x.id}','rejected')">Reject</button>`:""}
        </td></tr>`).join("")}
      ${p.length===0?`<tr><td colspan="5" style="text-align:center;color:var(--text3);padding:40px;">No products found</td></tr>`:""}
      </tbody></table>
    </div>`;
}

// Orders
function renderOrders() {
  const o = cachedData.orders;
  return `
    <div class="stats-grid">
      <div class="stat-card warning"><div class="label">Pending</div><div class="value">${o.filter(x=>x.order_status==="pending").length}</div></div>
      <div class="stat-card primary"><div class="label">Shipped</div><div class="value">${o.filter(x=>x.order_status==="shipped").length}</div></div>
      <div class="stat-card success"><div class="label">Delivered</div><div class="value">${o.filter(x=>x.order_status==="delivered").length}</div></div>
      <div class="stat-card accent"><div class="label">Cancelled</div><div class="value">${o.filter(x=>x.order_status==="cancelled").length}</div></div>
    </div>
    <div class="table-card">
      <div class="table-header">
        <h3>All Orders (${o.length})</h3>
        <div class="filter-row">
          <select onchange="filterOrders(this.value)">
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>
      <table><thead><tr><th>Order #</th><th>Customer</th><th>Amount</th><th>Status</th><th>Update</th></tr></thead>
      <tbody id="ordersTable">
      ${o.map(x=>`<tr>
        <td><strong>${x.order_number||x.id?.slice(0,8)}</strong></td>
        <td>${truncate(x.customer_name||"—",20)}</td>
        <td>${formatPKR(x.total_amount_pkr)}</td>
        <td>${statusBadge(x.order_status)}</td>
        <td>
          <select onchange="updateOrderStatus('${x.id}',this.value)" style="background:var(--bg);border:1px solid var(--border);color:var(--text);padding:4px 8px;border-radius:6px;font-size:11px;">
            ${["pending","processing","shipped","delivered","cancelled"].map(s=>`<option value="${s}" ${x.order_status===s?"selected":""}>${s.charAt(0).toUpperCase()+s.slice(1)}</option>`).join("")}
          </select>
        </td></tr>`).join("")}
      ${o.length===0?`<tr><td colspan="5" style="text-align:center;color:var(--text3);padding:40px;">No orders found</td></tr>`:""}
      </tbody></table>
    </div>`;
}

// Payouts
function renderPayouts() {
  const p = cachedData.payouts;
  return `
    <div class="table-card">
      <div class="table-header">
        <h3>Withdrawal Requests (${p.length})</h3>
        <div class="filter-row">
          <select onchange="filterPayouts(this.value)">
            <option value="all">All</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>
      <table><thead><tr><th>Seller</th><th>Amount</th><th>Method</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody id="payoutsTable">
      ${p.map(x=>`<tr>
        <td>${x.seller_id?.slice(0,8)||"—"}</td>
        <td><strong>${formatPKR(x.amount)}</strong></td>
        <td>${x.payout_method||"Bank"}</td>
        <td>${statusBadge(x.status)}</td>
        <td>
          ${x.status==="pending"?`<button class="action-btn success" onclick="updatePayoutStatus('${x.id}','completed')">Approve</button><button class="action-btn danger" onclick="updatePayoutStatus('${x.id}','rejected')">Reject</button>`:"—"}
        </td></tr>`).join("")}
      ${p.length===0?`<tr><td colspan="5" style="text-align:center;color:var(--text3);padding:40px;">No withdrawal requests</td></tr>`:""}
      </tbody></table>
    </div>`;
}

// Sync
function renderSync() {
  const isOnline = navigator.onLine;
  return `
    <div class="sync-card">
      <h3 style="margin-bottom:16px;">Connection Status</h3>
      <div class="sync-status-big">
        <div class="dot" style="width:16px;height:16px;border-radius:50%;background:${isOnline?"var(--success)":"var(--danger)"}"></div>
        <div>
          <strong style="font-size:16px;">${isOnline?"Online":"Offline"}</strong>
          <p style="font-size:12px;color:var(--text2)">${isOnline?"Connected to FANZON servers":"Working with local data"}</p>
        </div>
      </div>
      <div style="display:flex;gap:12px;margin-bottom:16px;">
        <button class="sync-btn" onclick="manualSync()" ${!isOnline?"disabled":""}>🔄 Sync Now</button>
      </div>
      <p style="font-size:12px;color:var(--text3)">Last sync: ${sync?.lastSync ? new Date(sync.lastSync).toLocaleString() : "Never"}</p>
    </div>
    <div class="sync-card">
      <h3 style="margin-bottom:12px;">Local Data Summary</h3>
      <div class="stats-grid">
        <div class="stat-card"><div class="label">Sellers</div><div class="value">${cachedData.sellers.length}</div></div>
        <div class="stat-card"><div class="label">Products</div><div class="value">${cachedData.products.length}</div></div>
        <div class="stat-card"><div class="label">Orders</div><div class="value">${cachedData.orders.length}</div></div>
        <div class="stat-card"><div class="label">Payouts</div><div class="value">${cachedData.payouts.length}</div></div>
      </div>
    </div>
    <div class="sync-card">
      <h3 style="margin-bottom:12px;">Sync Log</h3>
      <div class="sync-log" id="syncLogList"><p style="color:var(--text3);font-size:12px;">Loading...</p></div>
    </div>`;
}

// Settings
function renderSettings() {
  return `
    <div class="settings-card">
      <h3>🔐 Change Password</h3>
      <label>New Password</label>
      <input type="password" id="newPass" placeholder="Enter new password" />
      <label>Confirm Password</label>
      <input type="password" id="confirmPass" placeholder="Confirm new password" />
      <button class="btn" onclick="changePassword()">Update Password</button>
    </div>
    <div class="settings-card">
      <h3>🎨 Appearance</h3>
      <div style="display:flex;align-items:center;gap:12px;margin-top:8px;">
        <span style="font-size:13px;">Dark Mode</span>
        <button class="theme-toggle" onclick="toggleTheme()" id="settingsThemeToggle"></button>
        <span style="font-size:13px;">Light Mode</span>
      </div>
    </div>
    <div class="settings-card">
      <h3>ℹ️ About</h3>
      <p style="font-size:13px;color:var(--text2);line-height:1.8;">
        <strong>FANZON Admin Panel</strong> v1.0.0<br>
        Platform: ${window.fanzonAdmin?.platform || "Web"}<br>
        Database: IndexedDB (Offline) + Supabase (Online)<br>
        Auto-sync: Every 60 seconds when online
      </p>
    </div>`;
}

// ========== ACTION HANDLERS ==========
async function updateSellerStatus(userId, status) {
  const seller = cachedData.sellers.find(s => s.user_id === userId);
  if (!seller) return;
  seller.verification_status = status;
  await db.put("sellers", seller);
  if (navigator.onLine) {
    try { await api.updateSeller(userId, { verification_status: status }); await db.markSynced("sellers", seller.id); } catch(e) { console.warn(e); }
  }
  await loadPageData();
}

async function updateProductStatus(id, status) {
  const prod = cachedData.products.find(p => p.id === id);
  if (!prod) return;
  prod.status = status;
  await db.put("products", prod);
  if (navigator.onLine) {
    try { await api.updateProduct(id, { status }); await db.markSynced("products", id); } catch(e) { console.warn(e); }
  }
  await loadPageData();
}

async function updateOrderStatus(id, status) {
  const order = cachedData.orders.find(o => o.id === id);
  if (!order) return;
  order.order_status = status;
  await db.put("orders", order);
  if (navigator.onLine) {
    try { await api.updateOrder(id, { order_status: status }); await db.markSynced("orders", id); } catch(e) { console.warn(e); }
  }
  await loadPageData();
}

async function updatePayoutStatus(id, status) {
  const payout = cachedData.payouts.find(p => p.id === id);
  if (!payout) return;
  payout.status = status;
  await db.put("payouts", payout);
  if (navigator.onLine) {
    try { await api.updatePayout(id, { status }); await db.markSynced("payouts", id); } catch(e) { console.warn(e); }
  }
  await loadPageData();
}

async function changePassword() {
  const p = document.getElementById("newPass").value;
  const c = document.getElementById("confirmPass").value;
  if (!p || p.length < 6) return alert("Password must be at least 6 characters");
  if (p !== c) return alert("Passwords don't match");
  if (!navigator.onLine) return alert("Internet required to change password");
  try { await api.changePassword(p); alert("Password updated!"); } catch(e) { alert("Error: " + e.message); }
}

async function manualSync() {
  if (!navigator.onLine) return alert("No internet connection");
  await sync.fullSync();
}

// Filters (simple client-side)
function filterSellers(v) { /* re-render with filter */ }
function filterProducts(v) { /* re-render with filter */ }
function filterOrders(v) { /* re-render with filter */ }
function filterPayouts(v) { /* re-render with filter */ }
function searchSellers(q) { /* search */ }
function searchProducts(q) { /* search */ }

// ========== BOOT ==========
document.addEventListener("DOMContentLoaded", initApp);
