/**
 * FANZON Admin - SQLite Database Layer
 * Offline-first database with sync capability
 */

class FanzonDB {
  constructor() {
    this.db = null;
    this.isReady = false;
  }

  async init() {
    // Use IndexedDB for browser-compatible offline storage
    return new Promise((resolve, reject) => {
      const request = indexedDB.open("FanzonAdminDB", 3);
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        // Sellers store
        if (!db.objectStoreNames.contains("sellers")) {
          const sellers = db.createObjectStore("sellers", { keyPath: "id" });
          sellers.createIndex("status", "verification_status");
          sellers.createIndex("synced", "synced");
        }
        
        // Products store
        if (!db.objectStoreNames.contains("products")) {
          const products = db.createObjectStore("products", { keyPath: "id" });
          products.createIndex("status", "status");
          products.createIndex("seller_id", "seller_id");
          products.createIndex("synced", "synced");
        }
        
        // Orders store
        if (!db.objectStoreNames.contains("orders")) {
          const orders = db.createObjectStore("orders", { keyPath: "id" });
          orders.createIndex("status", "order_status");
          orders.createIndex("synced", "synced");
        }
        
        // Payouts store
        if (!db.objectStoreNames.contains("payouts")) {
          const payouts = db.createObjectStore("payouts", { keyPath: "id" });
          payouts.createIndex("status", "status");
          payouts.createIndex("synced", "synced");
        }
        
        // Sync log
        if (!db.objectStoreNames.contains("sync_log")) {
          db.createObjectStore("sync_log", { keyPath: "id", autoIncrement: true });
        }

        // Settings
        if (!db.objectStoreNames.contains("settings")) {
          db.createObjectStore("settings", { keyPath: "key" });
        }
      };
      
      request.onsuccess = (event) => {
        this.db = event.target.result;
        this.isReady = true;
        resolve(this);
      };
      
      request.onerror = () => reject(request.error);
    });
  }

  // Generic CRUD
  async getAll(storeName) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async getById(storeName, id) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async put(storeName, data) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      const req = store.put({ ...data, synced: false, updated_at: new Date().toISOString() });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async putBulk(storeName, items) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      items.forEach(item => store.put({ ...item, synced: true }));
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  }

  async delete(storeName, id) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      const req = store.delete(id);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  async getUnsynced(storeName) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readonly");
      const store = tx.objectStore(storeName);
      const index = store.index("synced");
      const req = index.getAll(false);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async markSynced(storeName, id) {
    const item = await this.getById(storeName, id);
    if (item) {
      item.synced = true;
      return this.putDirect(storeName, item);
    }
  }

  async putDirect(storeName, data) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      const req = store.put(data);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async addSyncLog(entry) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction("sync_log", "readwrite");
      const store = tx.objectStore("sync_log");
      const req = store.add({ ...entry, timestamp: new Date().toISOString() });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async getSyncLogs() {
    return this.getAll("sync_log");
  }

  async getSetting(key) {
    const item = await this.getById("settings", key);
    return item?.value;
  }

  async setSetting(key, value) {
    return this.putDirect("settings", { key, value });
  }

  async getStats() {
    const sellers = await this.getAll("sellers");
    const products = await this.getAll("products");
    const orders = await this.getAll("orders");
    const payouts = await this.getAll("payouts");
    
    const totalRevenue = orders
      .filter(o => o.order_status === "delivered")
      .reduce((sum, o) => sum + (o.total_amount_pkr || 0), 0);

    return {
      totalSellers: sellers.length,
      totalProducts: products.length,
      totalOrders: orders.length,
      totalRevenue,
      pendingSellers: sellers.filter(s => s.verification_status === "pending").length,
      pendingProducts: products.filter(p => p.status === "pending").length,
      pendingPayouts: payouts.filter(p => p.status === "pending").length,
      ordersByStatus: {
        pending: orders.filter(o => o.order_status === "pending").length,
        processing: orders.filter(o => o.order_status === "processing").length,
        shipped: orders.filter(o => o.order_status === "shipped").length,
        delivered: orders.filter(o => o.order_status === "delivered").length,
        cancelled: orders.filter(o => o.order_status === "cancelled").length,
      }
    };
  }
}

window.FanzonDB = FanzonDB;
