#!/bin/bash
echo "============================================"
echo "  FANZON Admin Panel - Setup (Mac/Linux)"
echo "============================================"
echo ""
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js not found! Install from: https://nodejs.org"
    exit 1
fi
echo "[OK] Node.js $(node --version) found"
echo ""
echo "Installing dependencies..."
npm install
echo ""
echo "[OK] Setup complete!"
echo ""
echo "To start: npm start"
echo "To build: npm run package:mac  (or package:linux)"
