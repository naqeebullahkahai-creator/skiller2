const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("fanzonDesktop", {
  getConfig: () => ipcRenderer.invoke("get-config"),
  getStore: (key) => ipcRenderer.invoke("get-store", key),
  setStore: (key, val) => ipcRenderer.invoke("set-store", key, val),
  platform: process.platform,
  appType: "seller",
});
