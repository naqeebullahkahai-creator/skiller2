# FANZON Seller Center Desktop v2.0

## Setup
1. Install Node.js from https://nodejs.org
2. Double-click setup.bat (Windows) or run ./setup.sh
3. Login with your seller account

## Build .exe: npm run build
## API Keys: Pre-configured, no setup needed!
