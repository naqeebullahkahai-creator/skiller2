@echo off
echo FANZON Seller Desktop - Setup
echo.
echo Installing dependencies...
call npm install
if errorlevel 1 (echo [ERROR] npm install failed! & pause & exit /b 1)
echo Starting...
call npm start
pause
