#!/bin/bash
echo "FANZON Seller Desktop - Setup"
npm install && npm start
