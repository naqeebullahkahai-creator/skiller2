@echo off
echo ========================================
echo    FANZON Mobile App Setup (Windows)
echo ========================================
echo.
echo Step 1: Installing dependencies...
call npm install
echo.
echo Step 2: Creating dist folder...
mkdir dist 2>nul
echo ^<html^>^<body^>Loading FANZON...^</body^>^</html^> > dist\index.html
echo.
echo Step 3: Adding Android platform...
call npx cap add android
echo.
echo Step 4: Syncing...
call npx cap sync
echo.
echo Step 5: Opening Android Studio...
call npx cap open android
echo.
echo ========================================
echo    DONE! Android Studio will open.
echo    Go to Build > Build APK to get .apk
echo ========================================
pause
