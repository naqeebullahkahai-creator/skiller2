import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fanzon.marketplace',
  appName: 'FANZON',
  webDir: 'dist',
  server: {
    url: 'https://fanzoon.lovable.app',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#0F766E'
    }
  }
};

export default config;
