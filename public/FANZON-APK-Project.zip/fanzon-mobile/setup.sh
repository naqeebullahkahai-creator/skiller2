#!/bin/bash
echo "========================================"
echo "   FANZON Mobile App Setup"
echo "========================================"
npm install
mkdir -p dist
echo '<html><body>Loading FANZON...</body></html>' > dist/index.html
npx cap add android
npx cap sync
npx cap open android
echo "DONE! Build APK in Android Studio."
