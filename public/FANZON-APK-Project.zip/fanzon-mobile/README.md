# FANZON Mobile App

## Quick Start
1. Install Node.js 18+ from https://nodejs.org
2. Install Java JDK 17 from https://adoptium.net
3. Install Android Studio from https://developer.android.com/studio
4. Run setup.bat (Windows) or setup.sh (Mac/Linux)
5. In Android Studio: Build > Build APK

## API Keys
- URL: https://faevzfibzcbuqjoatmjm.supabase.co
- Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhZXZ6ZmliemNidXFqb2F0bWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE3OTM4OTQsImV4cCI6MjA4NzM2OTg5NH0.1P6q4Xo5xKWHExRnUOaQPjwq-AxmQ6K4Sp4FTpWPXGM
